# please keep this version in sync with the latest version in CHANGELOG.md
__version__ = '1.1.0'
